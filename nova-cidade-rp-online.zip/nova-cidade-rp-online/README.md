# Nova Cidade RP – Online

Multiplayer do jogo: 8 servidores de 50 jogadores, todos na mesma cidade, com jogadores, NPCs, combate e chat compartilhados.
Não precisa instalar nada (zero dependências). Requer Node 18 ou mais novo.

## Testar no seu computador
1. Instale o Node.js (nodejs.org).
2. Abra um terminal nesta pasta e rode: `npm start`
3. Abra http://localhost:3000 em duas abas e jogue.

## Colocar no ar (Render, grátis)
1. Crie uma conta em github.com e um repositório novo (botão **New**).
2. No repositório: **Add file → Upload files** e envie `server.js`, `package.json`, `README.md` e a pasta `public` (com o `index.html` dentro). Clique em **Commit changes**.
3. Crie uma conta em render.com e clique em **New → Web Service**. Conecte o GitHub e escolha o repositório.
4. Preencha: **Runtime** Node · **Build Command** `npm install` · **Start Command** `npm start` · **Instance Type** Free.
5. Clique em **Create Web Service**. Em 1–2 minutos você recebe um link `https://nome.onrender.com`. Esse link é o jogo online: qualquer pessoa entra, sem conta.

Outras opções que servem do mesmo jeito: Railway, Fly.io ou qualquer VPS com Node.

## Verificar se está funcionando
- `/health` responde `ok`.
- `/status` mostra quantos jogadores há em cada servidor (ex.: `"srv1":"12/50"`).

## Bom saber
- O plano grátis do Render "dorme" sem uso; o primeiro acesso pode levar cerca de 1 minuto.
- Reiniciar o servidor desconecta todos (o jogo tenta reconectar sozinho).
- Os saves (dinheiro, missões) ficam no navegador de cada jogador, não no servidor.
- Não há anti-cheat: o jogo de cada pessoa decide o próprio estado. Use com amigos ou comunidade de confiança.
- Para mudar o limite por servidor: variável de ambiente `MAX_PLAYERS` (padrão 50).
